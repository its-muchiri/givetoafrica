-- AlterTable (no structural changes, only adding unique index)

-- CreateIndex
CREATE UNIQUE INDEX "donations_providerTransactionId_key" ON "donations"("providerTransactionId");
